from django.shortcuts import render
from django.http import HttpResponse


def settingsHome(request):
    return HttpResponse("settings configuration")
